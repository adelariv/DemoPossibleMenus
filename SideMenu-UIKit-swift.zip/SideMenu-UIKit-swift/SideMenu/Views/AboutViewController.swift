//
//  AboutViewController.swift
//  SideMenu
//
//  Created by Errol DMello on 29/09/21.
//

import UIKit

final class AboutViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .blue
        title = "About Us"
    }
}
