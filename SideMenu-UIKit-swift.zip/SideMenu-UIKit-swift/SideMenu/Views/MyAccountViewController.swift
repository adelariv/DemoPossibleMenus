//
//  MyAccountViewController.swift
//  SideMenu
//
//  Created by Errol DMello on 29/09/21.
//

import UIKit

final class MyAccountViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .magenta
        title = "My Account"
    }
}
